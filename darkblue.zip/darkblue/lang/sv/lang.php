<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['__link__']              = 'Den generella länkfärgen';
$lang['__existing__']          = 'Färg på länkar till existerande sidor';
$lang['__missing__']           = 'Färg på länkar till sidor som inte finns';
$lang['__site_width__']        = 'Bredden på hela webbsidan (kan anges i valfri längdenhet: %, px, em, ...)';
$lang['__sidebar_width__']     = 'Bredden på sidokolumnen, om existerande (kan anges i valfri längdenhet: %, px, em, ...)';
