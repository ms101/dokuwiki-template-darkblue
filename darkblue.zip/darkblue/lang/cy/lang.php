<?php

// style.ini values

$lang['__background_site__'] = 'Lliw am y cefndir (tu ôl y blwch cynnwys)';
$lang['__link__']     = 'Lliw dolenni cyffredinol';
$lang['__existing__'] = 'Lliw dolenni i dudalennau sy\'n bodoli';
$lang['__missing__']  = 'Lliw dolenni i dudalennau sy ddim yn bodoli';
$lang['__site_width__']    = 'Lled y safle cyfan (unrhyw uned: %, px, em, ...)';
$lang['__sidebar_width__'] = 'Lled y bar ochr, os oes un (unrhyw uned: %, px, em, ...)';
$lang['__tablet_width__']  = 'O dan y lled sgrin hwn, bydd y safle yn newid i fodd tabled';
$lang['__phone_width__']   = 'O dan y lled sgrin hwn, bydd y safle yn newid i fodd ffôn';
